package com.higerphi.praktik

data class Users(val name:String?)
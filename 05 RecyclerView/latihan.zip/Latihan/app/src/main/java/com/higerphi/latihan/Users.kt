package com.higerphi.latihan

data class Users(val name:String?)
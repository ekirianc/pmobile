package com.pm.latihan

data class PhoneData (val phone: Long, val contactName: String, val alamat: String)


package com.higerphi.praktik

data class PhoneData (val harga: String, val modelLaptop: String, val spek: String)


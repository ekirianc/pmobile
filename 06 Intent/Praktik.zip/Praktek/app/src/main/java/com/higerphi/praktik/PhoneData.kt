package com.higerphi.praktek

data class PhoneData (val phone: Long, val contactName: String)

